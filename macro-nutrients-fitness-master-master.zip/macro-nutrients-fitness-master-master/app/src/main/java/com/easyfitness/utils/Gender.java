package com.easyfitness.utils;

public class Gender {
    public static final int UNKNOWN = 0;
    public static final int MALE = 1;
    public static final int FEMALE = 2;
    public static final int OTHER = 3;
}
