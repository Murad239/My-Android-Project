package com.water;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.easyfitness.R;

public class WaterTestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_water_test);
    }
}
